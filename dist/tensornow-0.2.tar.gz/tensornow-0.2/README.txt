# Offical Python Interface to [TensorNow](http://tensornow.com).

## Installation
``` pip install TensorNow ```

## Documentation

Please visit the documentation available [here](http://tensornow.com/documentation).

## License

``` TensorNow ``` is under the [MIT License](https://github.com/codeandproduce/TensorNow/blob/master/LICENSE).
