from tensornow.Now import Now

